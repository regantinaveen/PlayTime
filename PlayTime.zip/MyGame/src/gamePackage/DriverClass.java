package gamePackage;

public class DriverClass {
	
	
	@SuppressWarnings("unused")
	public static void main(String[] args){
		GameFrame gf = new GameFrame();
	}

}
